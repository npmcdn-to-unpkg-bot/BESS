A Pen created at CodePen.io. You can find this one at http://codepen.io/amsul/pen/nGckA.

 extend to get corresponding pickers with “from” and ”to” behavior.